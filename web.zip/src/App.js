import { useState } from 'react';
import InitialSetup from './initialSetup';
import NoiseOverlay from './NoiseOverlay';
import { Canvas } from '@react-three/fiber';
import './DesktopView.css';

function App() {
  const [enteredDesktop, setEnteredDesktop] = useState(false);

  return (
    <>
      {!enteredDesktop ? (
        <InitialSetup onEnterDesktop={() => setEnteredDesktop(true)} />
      ) : (
       <div className="desktop-screen">
        <iframe src="/legacy-site/index.html" className="website-frame" />
        {/* <Canvas className="noise-overlay" orthographic camera={{ zoom: 1, position: [0, 0, 1] }}>
          <NoiseOverlay />
        </Canvas> */}
      </div>

      )}
    </>
  );
}

export default App;
