import * as THREE from 'three';
import CSS3DObject      from 'three/examples/jsm/renderers/CSS3DRenderer.js';
import Application from '../Application';
import EventEmitter from '../Utils/EventEmitter';

const SCREEN_SIZE = { w: 1280, h: 1024 };
const IFRAME_PADDING = 32;
const IFRAME_SIZE = {
    w: SCREEN_SIZE.w - IFRAME_PADDING,
    h: SCREEN_SIZE.h - IFRAME_PADDING,
};

export default class MonitorScreen extends EventEmitter {
    constructor() {
        super();
        this.application = new Application();
        this.scene = this.application.scene;
        this.cssScene = this.application.cssScene;
        this.sizes = this.application.sizes;
        this.resources = this.application.resources;
        this.screenSize = new THREE.Vector2(SCREEN_SIZE.w, SCREEN_SIZE.h);
        this.camera = this.application.camera;
        this.position = new THREE.Vector3(0, 950, 255);
        this.rotation = new THREE.Euler(-3 * THREE.MathUtils.DEG2RAD, 0, 0);
        this.videoTextures = {};
        this.mouseClickInProgress = false;
        this.shouldLeaveMonitor = false;

        this.initializeScreenEvents();
        this.createIframe();
        const maxOffset = this.createTextureLayers();
        this.createEnclosingPlanes(maxOffset);
        this.createPerspectiveDimmer(maxOffset);
    }

    initializeScreenEvents() {
        document.addEventListener('mousemove', (event) => {
            const id = event.target.id;
            if (id === 'computer-screen') {
                event.inComputer = true;
            }

            this.inComputer = event.inComputer;

            if (this.inComputer && !this.prevInComputer) {
                this.camera.trigger('enterMonitor');
            }

            if (!this.inComputer && this.prevInComputer && !this.mouseClickInProgress) {
                this.camera.trigger('leftMonitor');
            }

            if (!this.inComputer && this.mouseClickInProgress && this.prevInComputer) {
                this.shouldLeaveMonitor = true;
            } else {
                this.shouldLeaveMonitor = false;
            }

            this.application.mouse.trigger('mousemove', [event]);

            this.prevInComputer = this.inComputer;
        }, false);

        document.addEventListener('mousedown', (event) => {
            this.inComputer = event.inComputer;
            this.application.mouse.trigger('mousedown', [event]);
            this.mouseClickInProgress = true;
            this.prevInComputer = this.inComputer;
        }, false);

        document.addEventListener('mouseup', (event) => {
            this.inComputer = event.inComputer;
            this.application.mouse.trigger('mouseup', [event]);

            if (this.shouldLeaveMonitor) {
                this.camera.trigger('leftMonitor');
                this.shouldLeaveMonitor = false;
            }

            this.mouseClickInProgress = false;
            this.prevInComputer = this.inComputer;
        }, false);
    }

    createIframe() {
        const container = document.createElement('div');
        container.style.width = this.screenSize.width + 'px';
        container.style.height = this.screenSize.height + 'px';
        container.style.opacity = '1';
        container.style.background = '#1d2e2f';

        const iframe = document.createElement('iframe');

        iframe.onload = () => {
            if (iframe.contentWindow) {
                window.addEventListener('message', (event) => {
                    const evt = new CustomEvent(event.data.type, {
                        bubbles: true,
                        cancelable: false,
                    });

                    evt.inComputer = true;

                    if (event.data.type === 'mousemove') {
                        const clRect = iframe.getBoundingClientRect();
                        const { top, left, width, height } = clRect;
                        const widthRatio = width / IFRAME_SIZE.w;
                        const heightRatio = height / IFRAME_SIZE.h;
                        evt.clientX = Math.round(event.data.clientX * widthRatio + left);
                        evt.clientY = Math.round(event.data.clientY * heightRatio + top);
                    } else if (event.data.type === 'keydown' || event.data.type === 'keyup') {
                        evt.key = event.data.key;
                    }

                    iframe.dispatchEvent(evt);
                });
            }
        };

        const urlParams = new URLSearchParams(window.location.search);
        iframe.src = urlParams.has('dev') ? 'http://localhost:3000/' : 'https://os.henryheffernan.com/';
        iframe.style.width = this.screenSize.width + 'px';
        iframe.style.height = this.screenSize.height + 'px';
        iframe.style.padding = IFRAME_PADDING + 'px';
        iframe.style.boxSizing = 'border-box';
        iframe.style.opacity = '1';
        iframe.className = 'jitter';
        iframe.id = 'computer-screen';
        iframe.frameBorder = '0';
        iframe.title = 'HeffernanOS';

        container.appendChild(iframe);
        this.createCssPlane(container);
    }

    createCssPlane(element) {
        const object = new CSS3DObject(element);
        object.position.copy(this.position);
        object.rotation.copy(this.rotation);
        this.cssScene.add(object);

        const material = new THREE.MeshLambertMaterial({
            side: THREE.DoubleSide,
            opacity: 0,
            transparent: true,
            blending: THREE.NoBlending,
        });

        const geometry = new THREE.PlaneGeometry(this.screenSize.width, this.screenSize.height);
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(object.position);
        mesh.rotation.copy(object.rotation);
        mesh.scale.copy(object.scale);

        this.scene.add(mesh);
    }

    createTextureLayers() {
        const textures = this.resources.items.texture;
        this.getVideoTextures('video-1');
        this.getVideoTextures('video-2');

        const scaleFactor = 4;

        const layers = {
            smudge: {
                texture: textures.monitorSmudgeTexture,
                blending: THREE.AdditiveBlending,
                opacity: 0.12,
                offset: 24,
            },
            innerShadow: {
                texture: textures.monitorShadowTexture,
                blending: THREE.NormalBlending,
                opacity: 1,
                offset: 5,
            },
            video: {
                texture: this.videoTextures['video-1'],
                blending: THREE.AdditiveBlending,
                opacity: 0.5,
                offset: 10,
            },
            video2: {
                texture: this.videoTextures['video-2'],
                blending: THREE.AdditiveBlending,
                opacity: 0.1,
                offset: 15,
            },
        };

        let maxOffset = -1;
        for (const key in layers) {
            const layer = layers[key];
            const offset = layer.offset * scaleFactor;
            this.addTextureLayer(layer.texture, layer.blending, layer.opacity, offset);
            if (offset > maxOffset) maxOffset = offset;
        }
        return maxOffset;
    }

    getVideoTextures(videoId) {
        const video = document.getElementById(videoId);
        if (!video) {
            setTimeout(() => this.getVideoTextures(videoId), 100);
        } else {
            this.videoTextures[videoId] = new THREE.VideoTexture(video);
        }
    }

    addTextureLayer(texture, blendingMode, opacity, offset) {
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            blending: blendingMode,
            side: THREE.DoubleSide,
            opacity,
            transparent: true,
        });

        const geometry = new THREE.PlaneGeometry(this.screenSize.width, this.screenSize.height);
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(this.offsetPosition(this.position, new THREE.Vector3(0, 0, offset)));
        mesh.rotation.copy(this.rotation);
        this.scene.add(mesh);
    }

    createEnclosingPlanes(maxOffset) {
        const planes = {
            left: {
                size: new THREE.Vector2(maxOffset, this.screenSize.height),
                position: this.offsetPosition(this.position, new THREE.Vector3(-this.screenSize.width / 2, 0, maxOffset / 2)),
                rotation: new THREE.Euler(0, 90 * THREE.MathUtils.DEG2RAD, 0),
            },
            right: {
                size: new THREE.Vector2(maxOffset, this.screenSize.height),
                position: this.offsetPosition(this.position, new THREE.Vector3(this.screenSize.width / 2, 0, maxOffset / 2)),
                rotation: new THREE.Euler(0, 90 * THREE.MathUtils.DEG2RAD, 0),
            },
            top: {
                size: new THREE.Vector2(this.screenSize.width, maxOffset),
                position: this.offsetPosition(this.position, new THREE.Vector3(0, this.screenSize.height / 2, maxOffset / 2)),
                rotation: new THREE.Euler(90 * THREE.MathUtils.DEG2RAD, 0, 0),
            },
            bottom: {
                size: new THREE.Vector2(this.screenSize.width, maxOffset),
                position: this.offsetPosition(this.position, new THREE.Vector3(0, -this.screenSize.height / 2, maxOffset / 2)),
                rotation: new THREE.Euler(90 * THREE.MathUtils.DEG2RAD, 0, 0),
            },
        };

        for (const key in planes) {
            this.createEnclosingPlane(planes[key]);
        }
    }

    createEnclosingPlane(plane) {
        const material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            color: 0x48493f,
        });

        const geometry = new THREE.PlaneGeometry(plane.size.x, plane.size.y);
        const mesh = new THREE.Mesh(geometry, material);

        mesh.position.copy(plane.position);
        mesh.rotation.copy(plane.rotation);
        this.scene.add(mesh);
    }

    createPerspectiveDimmer(maxOffset) {
        const material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            color: 0x000000,
            transparent: true,
            blending: THREE.AdditiveBlending,
        });

        const geometry = new THREE.PlaneGeometry(this.screenSize.width, this.screenSize.height);
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(this.offsetPosition(this.position, new THREE.Vector3(0, 0, maxOffset - 5)));
        mesh.rotation.copy(this.rotation);
        this.dimmingPlane = mesh;
        this.scene.add(mesh);
    }

    offsetPosition(position, offset) {
        const newPosition = new THREE.Vector3();
        newPosition.copy(position).add(offset);
        return newPosition;
    }

    update() {
        if (this.dimmingPlane) {
            const planeNormal = new THREE.Vector3(0, 0, 1);
            const viewVector = new THREE.Vector3().copy(this.camera.instance.position).sub(this.position).normalize();
            const dot = viewVector.dot(planeNormal);

            const dimPos = this.dimmingPlane.position;
            const camPos = this.camera.instance.position;

            const distance = Math.sqrt(
                (camPos.x - dimPos.x) ** 2 +
                (camPos.y - dimPos.y) ** 2 +
                (camPos.z - dimPos.z) ** 2
            );

            const opacity = 1 / (distance / 10000);
            const DIM_FACTOR = 0.7;

            this.dimmingPlane.material.opacity = (1 - opacity) * DIM_FACTOR + (1 - dot) * DIM_FACTOR;
        }
    }
}
