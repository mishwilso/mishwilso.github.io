// File: windows/AboutWindow.js
function AboutWindow() {
  return React.createElement("div", { style: { padding: 16 } },
    React.createElement("h1", null, "About Me"),
    React.createElement("p", null, "This is rendered inside a retro window using React."),
    React.createElement("p", null, "You can use components, state, and more here!")
  );
}

window.AboutWindow = AboutWindow; // expose globally for reactMount.js
