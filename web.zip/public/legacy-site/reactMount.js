// File: reactMount.js
window.mountReactApp = function (targetEl, ComponentFn) {
  if (!targetEl) return;
  const root = ReactDOM.createRoot(targetEl);
  root.render(React.createElement(ComponentFn));
};
